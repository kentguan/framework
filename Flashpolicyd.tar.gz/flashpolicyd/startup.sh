#!/bin/sh
killall -9 FlashPolicyd
sleep 1
./FlashPolicyd ./bench.conf
			
