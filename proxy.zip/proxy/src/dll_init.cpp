#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <stdio.h>
#include "dll_init.h"

extern "C" {
#include <libtaomee/log.h>
}

#define DLFUNC_NO_ERROR(h, v, name) do { \
	v = (typeof v)dlsym (h, name); \
	dlerror (); \
}while (0)

#define DLFUNC(h, v, name) do { \
	v = (typeof v) dlsym (h, name); \
	if ((error = dlerror ()) != NULL) { \
		ERROR_LOG ("dlsym error, %s", error); \
		dlclose (h); \
		h = NULL; \
		goto out; \
	} \
}while (0)
	



int  register_plugin( proxy_dll_func_t & dll , const char *file_name)
{
	dll.handle=NULL;
	char *error; 
	int ret_code = -1;
	dll.handle = dlopen (file_name, RTLD_NOW);
	if ((error = dlerror()) != NULL) {
		ERROR_LOG ("dlopen error, %s", error);
		goto out;
	}
	
	DLFUNC (dll.handle, dll.proxy_get_lib_info, "proxy_get_lib_info");
	DLFUNC (dll.handle, dll.proxy_init_service, "proxy_init_service");
	DLFUNC (dll.handle, dll.proxy_fini_service, "proxy_fini_service");
	DLFUNC (dll.handle, dll.proxy_process_client_cmd, "proxy_process_client_cmd");
	DLFUNC (dll.handle, dll.proxy_process_serv_return, "proxy_process_serv_return");
	ret_code = 0;
out:
	BOOT_LOG (ret_code, "dlopen %s", file_name);
}
