/*
 * =====================================================================================
 *
 *       Filename:  Cexchange.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2009年03月10日 10时49分46秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jim (xcwen), jim@taomee.com
 *        Company:  taomee
 *
 * =====================================================================================
 */
#include "Cexchange.h"
Cexchange::Cexchange()  /* constructor */
{
	//初始化p_list
	this->p_list=(stru_exchange * )malloc( sizeof(stru_exchange )* EXCHANGE_ITEM_COUNT );
	this->curid=0;
	this->cur_timeout_id=1;
	memset(this->p_list,0,sizeof(stru_exchange)* EXCHANGE_ITEM_COUNT);
}

int Cexchange::add( int client_fd, uint32_t *p_id , stru_client_info ** pp_item)
{
	this->curid++;	
	//循环着用
	if(this->curid>=EXCHANGE_ITEM_COUNT)
		this->curid=(this->curid%EXCHANGE_ITEM_COUNT );

	*p_id=this->curid;	

	*pp_item=&(this->p_list[this->curid].c_item);

	if (!this->p_list[this->curid].isused){
		this->set_used(this->curid, client_fd );
		return SUCC;	
	}else{

		KERROR_LOG(0,"db return pkg  server out time addtime=%u cmdid=%04X,uid=%u ", 
					this->p_list[this->curid].add_time,
				   	(*pp_item)->client_cmdid, (*pp_item)->client_userid);

		//这个item 还处于使用中.将之设置为未使用
		this->set_nouse(this->curid );
		return FAIL;	
	}
	
}

int Cexchange::clear_by_client_fd(int client_fd )
{
	assert(client_fd<CLIENTFD_MAX );
	std::set< uint32_t > ::iterator it;
	//
	for (it=this->fd_protoid_set[client_fd].begin();
			it!=this->fd_protoid_set[client_fd].end();++it){
		this->p_list[*it].isused=false;
		KDEBUG_LOG(0,"close fd,unused:%u",*it );

	}
	this->fd_protoid_set[client_fd].clear();
	return SUCC;

}





int Cexchange::get(uint32_t id,userid_t userid, stru_client_info ** pp_item  )
{
	if (id>EXCHANGE_ITEM_COUNT ){
		ERROR_LOG(" GET EXCHAGNE ERROR id max :%u ",id );
		return FAIL; 
	};
	
	if( this->p_list[id].isused && 
			(this->p_list[id].c_item.db_userid==userid 
			 || this->p_list[id].c_item.db_userid==0 )
			){
		*pp_item=&(this->p_list[id].c_item);
		//设置其状态：未使用
		this->set_nouse(id);
		return  SUCC;
	}else{
		ERROR_LOG("db no return exhangeid[%u], isused[%u], cache userid[%u], uid[%u]", 
			id,this->p_list[id].isused , this->p_list[id].c_item.db_userid,userid);
		return FAIL;
	}
}

void Cexchange::add_always_succ( int client_fd, uint32_t *p_id,  stru_client_info ** pp_item)
{
	int exchange_ret=FAIL;
	while (exchange_ret!=SUCC){
		exchange_ret= this->add(client_fd , p_id,pp_item)	;
		if (exchange_ret!=SUCC){
			//超时报文的处理 TODO 
			//暂不返回错误报文
			//ERROR_LOG("db return pkg  server out time  client\t cmdid =%04X,uid=%u", 
			//		(*pp_item)->client_cmdid, (*pp_item)->client_userid);
		}
	}
}

void Cexchange::do_timeout_pkg(uint32_t last_time )
{
	while (this->p_list[this->cur_timeout_id].add_time<=last_time&&
			this->p_list[this->cur_timeout_id].add_time>0
			){
		//时间够了
		if (this->p_list[this->cur_timeout_id].isused )	{
			//还在使用中，说明还没有返回，则为超时
			//发出超时错误报文
			proto_header_t ph;
			ph.proto_length=PROTO_HEADER_SIZE;
			ph.proto_id=this->p_list[this->cur_timeout_id].c_item.client_protoid;
			ph.cmd_id=this->p_list[this->cur_timeout_id].c_item.client_cmdid;
			ph.result=NET_TIMEOUT_ERR;
			ph.id=this->p_list[this->cur_timeout_id].c_item.client_userid;
		
			ERROR_LOG(" SERVER TIMEOUT,exchange id[%u],  CMDID=%04X,UID=%u",
				   this->cur_timeout_id,ph.cmd_id,ph.id );
			send_pkg_to_client(this->p_list[this->cur_timeout_id].c_item.p_client ,
					(void *) &ph , ph.proto_length );

			asynsvr_send_warning_msg( "db timeout",  ph.id ,ph.cmd_id, 1,"" );
	
			//设置其未使用
			this->set_nouse(this->cur_timeout_id);			
		}

		//防止死循环
		this->p_list[this->cur_timeout_id].add_time=0;

		this->cur_timeout_id++;	
		if(this->cur_timeout_id>=EXCHANGE_ITEM_COUNT)
			this->cur_timeout_id=(this->cur_timeout_id%EXCHANGE_ITEM_COUNT );
	}
}
