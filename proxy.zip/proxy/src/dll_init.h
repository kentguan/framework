#ifndef _DLL_H_
#define _DLL_H_
#include <sys/types.h>
#include  "proxy_dll_interface.h"

//proxy 保存客户端命令的信息

typedef struct stru_proxy_dll_func{
	void *handle;

	int (*proxy_get_lib_info)(stru_lib_info *p_out );
	int (*proxy_init_service) ();
	int (*proxy_fini_service) ();
	int (*proxy_process_client_cmd)(char* recvbuf,int recvlen, 
			stru_client_info * p_client_info , stru_proxy_interface_out *p_out);
	int (*proxy_process_serv_return)(char* recvbuf,int recvlen, stru_pri_buf * p_pri_buf,
		           stru_proxy_interface_out *p_out);
} proxy_dll_func_t;

extern int  register_plugin( proxy_dll_func_t & dll , const char *file_name);

#endif
