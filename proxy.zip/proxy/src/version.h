/*
 * =====================================================================================
 * 
 *       Filename:  version.h
 * 
 *    Description:  
 * 
 *        Version:  1.0
 *        Created:  2008年09月09日 10时21分13秒 CST
 *       Revision:  none
 *       Compiler:  gcc
 * 
 *         Author:  xcwen (xcwen), xcwenn@gmail.com
 *        Company:  TAOMEE
 *
 *      ------------------------------------------------------------
 *      view configure:
 *          VIM:  set tabstop=4  
 * 
 * =====================================================================================
 */

#ifndef  VERSION_INC
#define  VERSION_INC
const char *proxy_version_str="PROXY:2011-06-15";
#endif   /* ----- #ifndef VERSION_INC  ----- */

