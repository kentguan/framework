/*
 * =====================================================================================
 * 
 *	   Filename:  common.h
 * 
 *	Description:  
 * 
 *		Version:  1.0
 *		Created:  2007年11月02日 18时33分18秒 CST
 *	   Revision:  none
 *	   Compiler:  gcc
 * 
 *		 Author:  xcwen (xcwen), xcwenn@gmail.com
 *		Company:  TAOMEE
 * 
 * =====================================================================================
 */

#ifndef  proxy_route   
#define  proxy_route 

//库标示:
//当第1,2个bit为1时：			00111110 11100000 	
//								==库标示8位(256个库)(可用命令号64个) routeid in [100,355]
//其它：					    11111110 00000000   
//								==库标示6.5位(96个库)(可用命令号512个) routeid in [0,95]

#define GET_ROUTE(cmdid) (((cmdid&0xC000)==0xC000)?(100+((cmdid&0x3E00)>>6)+((cmdid &0x00E0)>>5)):(cmdid>>9))  

#endif   /* ----- #ifndef COMMON_INC  ----- */

