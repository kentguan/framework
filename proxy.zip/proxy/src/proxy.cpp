/**
 *============================================================
 *  @file      proxy.cpp
 *  @brief
 * 
 *  compiler   gcc4.1.2
 *  platform   Linux
 *
 *  copyright:  TaoMee, Inc. ShangHai CN. All rights reserved.
 *
 *============================================================
 */

extern "C" {
#include <libtaomee/list.h>
#include <libtaomee/log.h>
#include <libtaomee/timer.h>

#include <async_serv/dll.h>
#include <async_serv/net_if.h>
#include <libtaomee/conf_parser/config.h>
}
#include <libtaomee++/utils/strings.hpp>
#include <libtaomee++/utils/tcpip.h>
#include "Cnew_route.h" 
#include "Cexchange.h" 
#include "version.h"
//#include "db_macro.h"

inline const char * config_get_strval_with_def(const char* key,const char* def ="" ){
    const char *  v= config_get_strval(key)  ;
    if ( v!=NULL){
        return  v;
    }else{
        return def;
    }
}



#include<unistd.h>
#include<signal.h>

//全局路由数据
Cnew_route *route=NULL; 
//保存交换信息
Cexchange *exchange=NULL ; 

typedef struct TmrTest {
    list_head_t timer_list;
} tmr_test_t;
tmr_test_t tmr;

//处理超时报文
int do_time_out_pkg (void* owner, void* data)
{
	exchange->do_timeout_pkg(get_now_tv()->tv_sec-10 );	
	//追加定时操作
	ADD_TIMER_EVENT(&tmr, do_time_out_pkg, NULL, get_now_tv()->tv_sec + 1);
    return 0;
}



// hex 日志
void log_pkg_data(uint32_t log_flag ,const char* fix_str,const char*buf,const int len , uint32_t ip=0);

void deal_interface_out_func(stru_proxy_interface_out *p_in,stru_client_info *p_client_item );


//启动时间
uint32_t g_start_time=0;
//重新加载时间
uint32_t g_reload_time=0;
#include "dll_init.h" 
#include <set>
#include <map>
#include <vector>

//proxy 重新加载配置文件
#define proxy_reload_route_config_cmd		0x01FA

//proxy 得到相关信息
#define proxy_get_info_cmd					0x01FB

//proxy 得到版本信息
#define proxy_get_version_cmd					0x0000
struct proxy_get_version_out{
	char msg[255];
};

struct proxy_get_info_out{
	uint32_t log_level;
	uint32_t start_time;
	uint32_t reload_time;
	uint32_t page_size;
	char msg[200];
};

/**
 * 0:打印所有报文
 * 1:打印update报文
 * 2:不打印报文
 */
uint32_t log_proto_flag;


//检查进入的ip 的合法性
std::set<uint32_t>  g_ip_check_set;
//dll 模块列表
std::vector< proxy_dll_func_t > g_dll_list;

#include<signal.h>
void set_log_flag_handler( int value ) 
{
	log_proto_flag=(log_proto_flag+1)%3;
	DEBUG_LOG("SET_LOG_FLAG:%u,value:%u",log_proto_flag,value );
}

void set_reload_config_handler( int value ) 
{
	DEBUG_LOG("==RELOAD_CONFIG==pid:%d",getpid());
	if (route){//
		route->reinit_route(config_get_strval("route_file"));
	}
}

/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
  */
extern "C" int  init_service(int isparent)
{
	signal(SIGUSR1,set_reload_config_handler);
	signal(SIGUSR2,set_log_flag_handler);
	if (!isparent) {
	   	//处理定时器
	   	setup_timer(); 
	   	INIT_LIST_HEAD(&tmr.timer_list);
		ADD_TIMER_EVENT(&tmr, do_time_out_pkg, NULL, get_now_tv()->tv_sec + 1);

	
		g_start_time=time(NULL);
		boot_log(0,0,"VERSION:%s|compile:%s-%s|pagesize:%d",proxy_version_str,
			   	GetCompiledDate(__DATE__ ),__TIME__, page_size);

		route=new Cnew_route(config_get_strval("route_file") );
		exchange=new Cexchange();

		log_proto_flag=config_get_intval("LOG_PROTO_FLAG",0 );

		std::vector<std::string> string_list;
		std::vector<std::string>::iterator it;
		const char * conf_str= NULL;

		//ip限制	
		conf_str= config_get_strval_with_def("IP_CHECK_ENABLE_LIST");
		string_list=split(std::string(conf_str),',' );
		for(it=string_list.begin();it!=string_list.end();++it){
			printf ("IP-enable==[%s]%x\n",it->c_str(),ip2long(it->c_str()));
			g_ip_check_set.insert(ip2long(it->c_str()));
		}

		//加载其它配置的模块
		conf_str= config_get_strval_with_def("DLL_FILE_LIST");
		string_list=split(std::string(conf_str),',' );
		for(it=string_list.begin();it!=string_list.end();++it){
			proxy_dll_func_t dll={};
			register_plugin(dll,it->c_str());
			if (dll.handle!=NULL ){
				g_dll_list.push_back(dll);		
				dll.proxy_init_service();
				stru_lib_info lib_info; 
				dll.proxy_get_lib_info(&lib_info);
				printf("\tLIB:[%s]\n\tVERSION[%s]\n",lib_info.lib_name,lib_info.version );
			}
		}

	}

	return 0;
}

/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
  */
extern "C" int  fini_service(int isparent)
{
	if (!isparent) {
		//加载的模块处理
		std::vector< proxy_dll_func_t > ::iterator it;
		for(it=g_dll_list.begin();it!=g_dll_list.end();++it){
			it->proxy_fini_service();
		} 
	}
	return 0;
}

/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
  */
extern "C" void proc_events()
{
	//定时器
	handle_timer();
}
/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
  */
#include <stdio.h> 
extern "C" int  get_pkg_len(int fd, const void* avail_data, int avail_len, int isparent)
{	
	uint32_t reallen;

	if (avail_len >=4 )	
	{
		reallen=*((uint32_t* )avail_data );
		if (reallen<=(uint32_t)page_size) {
			if (reallen<PROTO_HEADER_SIZE){
				ERROR_LOG("reallen min err  %u",reallen);
				char outbuf[2000];
  				bin2hex (outbuf,(char*)avail_data,avail_len,500);
				ERROR_LOG("ERRORPKG:[%s] ",outbuf);

				return -1;
			}
			return reallen;
		}else{
			ERROR_LOG("reallen max err %u",reallen);
			char outbuf[2000];
  			bin2hex (outbuf,(char*)avail_data,avail_len,500);
			ERROR_LOG("ERRORPKG:[%s] ",outbuf);
			return -1;
		}
	}else return 0;

}

//处理自身命令
inline int do_proxy_cmd(void* recvbuf , int rcvlen , fdsession_t* fdsess )
{

	int ret;
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	//处理proxy 自身命令：
	switch ( p_proto_header->cmd_id) {
		//重新加载Route.conf 
		case proxy_reload_route_config_cmd:{ 
			g_reload_time=time(NULL);
			DEBUG_LOG("proxy_reload_route_config_cmd:passwd:%u",p_proto_header-> id );
			uint32_t passwd_value=config_get_intval("PROXY_RELOAD_ROUTE_PASSWD",142857);
			if (p_proto_header-> id==passwd_value){//密码保存在userid上
				FILE *pf=popen("killall -10 proxy","r");
				if (pf!=NULL){
					pclose(pf);
				}
				ret=SUCC;
			}else{
				ERROR_LOG("passwd:err:send%u,config:%u",p_proto_header-> id,passwd_value);
				ret=-2;
			}
			p_proto_header->result=ret;
			send_pkg_to_client(fdsess,recvbuf,rcvlen );
			return SUCC;
			break;
		}

		case proxy_get_info_cmd:{ //得到相关proxy 的信息
			char sendbuf[300]={0};int sendlen;
			proxy_get_info_out*p_out= (proxy_get_info_out*)(sendbuf+PROTO_HEADER_SIZE);
			set_std_return_p(sendbuf,&sendlen,p_proto_header,
					p_proto_header->proto_id,SUCC,sizeof(*p_out));
			p_out->log_level=log_proto_flag;
			p_out->start_time=g_start_time;
			p_out->reload_time=g_reload_time;
			p_out->page_size=page_size;
			snprintf (p_out->msg,sizeof(p_out->msg), "%s-%s", get_ip_ex(1),proxy_version_str ) ;
			send_pkg_to_client(fdsess ,(void *) sendbuf , sendlen );
			return SUCC;
		}
		case proxy_get_version_cmd:{ //得到相关proxy 的版本信息
			char sendbuf[300]={0};int sendlen;
			proxy_get_version_out *p_out= (proxy_get_version_out*)(sendbuf+PROTO_HEADER_SIZE);
			set_std_return_p(sendbuf,&sendlen,p_proto_header,
					p_proto_header->proto_id,SUCC,sizeof(*p_out));

			//得到lib 的版本信息
			std::string str;	
			std::vector< proxy_dll_func_t > ::iterator it;
			for(it=g_dll_list.begin();it!=g_dll_list.end();++it){
				stru_lib_info lib_info; 
				it->proxy_get_lib_info(&lib_info);
				str+=",";
				str+=lib_info.lib_name;
				str+=":";
				str+=lib_info.version;
			} 
			snprintf (p_out->msg,sizeof(p_out->msg), "%s|page_size:%d|%s|compile:%s-%s",proxy_version_str,page_size ,str.c_str(),GetCompiledDate(__DATE__ ),__TIME__ );

			send_pkg_to_client(fdsess ,(void *) sendbuf , sendlen );
			return SUCC;
		}

		default :
			break;
	}
	return FAIL;
};

/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
  */
extern "C" int  proc_pkg_from_client(void* recvbuf , int rcvlen , fdsession_t* fdsess)
{

	log_pkg_data(log_proto_flag , "I",(char*)recvbuf,rcvlen , fdsess->remote_ip );

	//检查ip的合法性
	if (g_ip_check_set.size()>0 ){//需要要验正
		if (g_ip_check_set.find(fdsess->remote_ip)==g_ip_check_set.end()){
			ERROR_LOG("err ip %s\n",long2ip(fdsess->remote_ip));
			return -1;
		}
	}

	//处理自身命令
	if (do_proxy_cmd(recvbuf , rcvlen , fdsess )==SUCC){
		//已经处理成功了，直接返回 
		return SUCC;
	};

	
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	

	uint32_t exchange_id;
	stru_client_info *p_client_item;

	//重构报文,并保存原有报文的信息
	{
		exchange->add_always_succ(fdsess->fd, &exchange_id,&p_client_item)	;
		p_client_item->p_client=fdsess ;
		p_client_item->client_protoid=p_proto_header->proto_id;
		p_client_item->client_userid=p_proto_header->id;
		p_client_item->client_cmdid=p_proto_header->cmd_id;

		p_client_item->db_userid=p_proto_header->id;
		//重设置proto_id 
		p_proto_header->proto_id=exchange_id;
	}

	//加载的模块处理
	std::vector< proxy_dll_func_t > ::iterator it;
	stru_proxy_interface_out interface_out;
	for(it=g_dll_list.begin();it!=g_dll_list.end();++it){
		if (it->proxy_process_client_cmd((char*)recvbuf,rcvlen,p_client_item,
					&interface_out)==SUCC){
			//交换列表中的记录没有使用
			exchange->set_nouse(exchange_id);	
			deal_interface_out_func(&interface_out,p_client_item );
			//不用再往后发了，返回
			return SUCC;
		} 
	} 

	//发送数据--
	int ret=0;
	ret=route->send_data(recvbuf);
	if (ret!=SUCC){//没有发送成功
		//设置当前的交换列表中的item的usedflag=false
		exchange->set_nouse(exchange_id);
		//返回标准错误报文
        KINFO_LOG(0,"[%d]send: err[%d] \n", getpid(),ret ) ;
		p_proto_header->proto_length=PROTO_HEADER_SIZE;
		p_proto_header->result=NET_ERR;
		p_proto_header->proto_id=p_client_item->client_protoid ;
		send_pkg_to_client( fdsess , recvbuf , PROTO_HEADER_SIZE );
		return SUCC;	
	}

	return SUCC;	
}


/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
 
 :*/
extern "C" void proc_pkg_from_serv(int fd, void* recvbuf , int rcvlen)
{
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	log_pkg_data(log_proto_flag,"O",(char*)recvbuf,rcvlen);
	//重构返回报文
	int exchange_ret=FAIL;
	stru_client_info *p_client_item;
	exchange_ret= exchange->get(p_proto_header->proto_id, p_proto_header->id ,&p_client_item)	;
	if (exchange_ret!=SUCC){//没有找
		//超时报文的处理
		//不处理
  		ERROR_LOG("server out time [fd=%d][userid=%u][cmdid=%04x] no return ", fd,
			  p_proto_header->id,p_proto_header->cmd_id	);
		return ; 
	}
	//加载的模块处理
	std::vector< proxy_dll_func_t > ::iterator it;
	stru_proxy_interface_out interface_out;
	for(it=g_dll_list.begin();it!=g_dll_list.end();++it){
		if (it->proxy_process_serv_return((char*)recvbuf,rcvlen,&(p_client_item->pri_buf),
					&interface_out)==SUCC){
			deal_interface_out_func(&interface_out,p_client_item );
			//不用再往后发了，返回
			return ;
		} 
	} 


	//正常返回
	p_proto_header->proto_id=p_client_item->client_protoid;
	send_pkg_to_client( p_client_item->p_client , recvbuf , rcvlen  );
	return ; 

}

/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
  */
extern "C" void on_client_conn_closed(int fd)
{
  DEBUG_LOG("client df close \t[fd=%d]", fd);
  exchange->clear_by_client_fd(fd );
}

/**
  * @brief AsyncServer框架要求实现的接口之一。 
  *
  */
extern "C" void on_fd_closed(int fd)
{
	DEBUG_LOG(" server df close \t[fd=%d]", fd);
	route->set_close_by_fd(fd);
}


//涉及到 route ,exchange
int send_to_server(char * recvbuf, stru_client_info* p_old_client_item)
{
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	uint32_t exchange_id;
	stru_client_info *p_client_item;
	log_pkg_data(log_proto_flag,"LIB->SVR",(char*)recvbuf,p_proto_header->proto_length );

	exchange->add_always_succ(p_old_client_item->p_client->fd , &exchange_id,&p_client_item);


	//将原来的交换信息保存,即:客户端的协议信息保存
	*p_client_item=*p_old_client_item;

	//返回报文里的id,要和 exchange 中的信息匹配.参见Cexchange.get 方法
	p_client_item->db_userid=p_proto_header->id;
	p_proto_header->proto_id=exchange_id;
	return route->send_data(recvbuf);		
}




//用于设置返回报文
void set_client_pkg(char * sendbuf, stru_client_info *p_client_item ,uint32_t ret ,uint32_t private_len)
{
	PROTO_HEADER *ph=(PROTO_HEADER*)sendbuf;
	ph->proto_length=PROTO_HEADER_SIZE+private_len;
	ph->proto_id=p_client_item->client_protoid;
	ph->cmd_id=p_client_item->client_cmdid;
	ph->result=ret;
	ph->id=p_client_item->client_userid;
}



void deal_interface_out_func(stru_proxy_interface_out *p_in,stru_client_info *p_client_item )
{
	char  client_out_buf[page_size*5];
	switch ( p_in->send_pkg_flag )
	{
		case FLAG_SEND_TO_CLIENT ://发给客户端
			if( p_in->send_client_result!=SUCC ){//返回错误码
				p_in->send_client_private_buf_len=0;
			}
			//设置报文头
			set_client_pkg(client_out_buf,p_client_item,p_in->send_client_result,
						p_in->send_client_private_buf_len );
			//设置报文的私有部分
			if (p_in->send_client_private_buf_len>0){
				memcpy(((char*)client_out_buf)+PROTO_HEADER_SIZE,p_in->send_client_private_buf,
				 p_in->send_client_private_buf_len );
			}
			send_pkg_to_client(p_client_item->p_client,(void *)client_out_buf , 
					((proto_header_t*)client_out_buf)->proto_length	);

			log_pkg_data(log_proto_flag,"LIB->CLI",(char*)client_out_buf , 
				((proto_header_t*)client_out_buf)->proto_length);

			break;
		case FLAG_SEND_TO_SERVER ://发给DB
			send_to_server(p_in->send_server_buf,p_client_item);
			break;
		default :
			break;
	}
};


inline void log_pkg_data(uint32_t log_flag ,const char* fix_str,const char*buf,const int len ,uint32_t ip )
{

	PROTO_HEADER* p_proto_header=((PROTO_HEADER *) buf);
	if (log_flag==0 ||
			(log_flag==1 && (p_proto_header->cmd_id&NEED_UPDATE)==NEED_UPDATE )  ){
		char outbuf[13000];
        bin2hex (outbuf,(char*)buf,len,500);
        INFO_LOG("%s[ip:0x%X][%04X][%u][%u][%04d][%s]",fix_str,ip,
				 p_proto_header->cmd_id,len,p_proto_header->id,
				p_proto_header ->result,outbuf );
	}else if (log_flag==1){
			INFO_LOG("%s[%04X][%u][%u]", fix_str,p_proto_header->cmd_id,
					p_proto_header->id, p_proto_header ->result);
	}else{//其它

	}
};

