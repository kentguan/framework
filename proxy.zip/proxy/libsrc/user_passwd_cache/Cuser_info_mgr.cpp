/**
 *============================================================
 *  @file      Cuser_info_mgr.cpp
 *  @brief
 * 
 *  compiler   gcc4.1.2
 *  platform   Linux
 *
 *  copyright:  TaoMee, Inc. ShangHai CN. All rights reserved.
 *
 *============================================================
 */

#include "Cuser_info_mgr.h"


Cuser_info_mgr::Cuser_info_mgr():user_passwd_cache() 
{
 		this->start_time=time(NULL);
 		this->diff_db_count=0;
		this->login_log_udp_sender.init(config_get_strval("LOGIN_LOG_IP"), 
				config_get_intval("LOGIN_LOG_PORT",0) );
		this->hit_count=0;
		this->request_count=0;
		this->passwd_err_count=0;
		this->check_db_passwd_flag=1;
}

Cuser_info_mgr::~Cuser_info_mgr()
{

}

void Cuser_info_mgr::userinfo_login_by_md5_two_o( void* recvbuf )
{
	userid_t userid;
	PROTO_HEADER * p_proto_header = (PROTO_HEADER *) recvbuf;	
	userid = p_proto_header->id;
	stru_trans_key key(recvbuf);
	DEBUG_LOG("userinfo_login_by_md5_two_o");

	if (p_proto_header->result == SUCC) {	
		stru_cache_info info={};
		//得到passwd	
		std::map<stru_trans_key, stru_cache_info>::iterator it;
		it = user_info_map.find(key);
		if (it != user_info_map.end()) {
			//保存密码
			memcpy(info.passwd_md5_two,it->second.passwd, PASSWD_LEN); 

			//检查是不是和缓存有冲突
			if (it->second.flag==1){
				//在缓存中密码验证失败，但在DB中却成功
				this->diff_db_count++;

				char db_passwd_buf[100];
		        bin2hex(db_passwd_buf, it->second.passwd,PASSWD_LEN);

				 
				//得到缓存中的密码
				stru_cache_info cache_info={};
				char cache_passwd_buf[100];
				this->user_passwd_cache.get_info(userid,&cache_info);
		        bin2hex(cache_passwd_buf,cache_info.passwd_md5_two,PASSWD_LEN);

				ERROR_LOG("DIFF userid:[%u] cache [%s] and db [%s]: ", 
						userid,cache_passwd_buf,db_passwd_buf  );
			}
				
		}else {			
			ERROR_LOG("no user:[%d]  info in memory \n", userid);
			return ;
		}			
			


		//得到flag
		info.flag = *((uint32_t*) (((char *)recvbuf)+PROTO_HEADER_SIZE));
		//设置数据
		user_passwd_cache.set_info(userid,info);
	} 

	user_info_map.erase(key);
	return ;

}



void Cuser_info_mgr::userinfo_log_with_stat_o( void* recvbuf )
{
	userid_t userid;
	PROTO_HEADER * p_proto_header = (PROTO_HEADER *) recvbuf;	
	userid = p_proto_header->id;
	stru_trans_key key(recvbuf);

	if (p_proto_header->result == SUCC) {	
		stru_cache_info info={};
		//得到passwd	
		std::map<stru_trans_key, stru_cache_info>::iterator it;
		it = user_info_map.find(key);
		if (it != user_info_map.end()) {
			//保存密码
			memcpy(info.passwd,it->second.passwd, PASSWD_LEN); 

			//检查是不是和缓存有冲突
			if (it->second.flag==1){
				//在缓存中密码验证失败，但在DB中却成功
				this->diff_db_count++;

				char db_passwd_buf[100];
		        bin2hex(db_passwd_buf, it->second.passwd,PASSWD_LEN);

				 
				//得到缓存中的密码
				stru_cache_info cache_info={};
				char cache_passwd_buf[100];
				this->user_passwd_cache.get_info(userid,&cache_info);
		        bin2hex(cache_passwd_buf,cache_info.passwd,PASSWD_LEN);

				ERROR_LOG("DIFF userid:[%u] cache [%s] and db [%s]: ", 
						userid,cache_passwd_buf,db_passwd_buf  );
			}
				
		}else {			
			ERROR_LOG("no user:[%d]  info in memory \n", userid);
			return ;
		}			
			


		//得到flag
		info.flag = *((uint32_t*) (((char *)recvbuf)+PROTO_HEADER_SIZE));
		//设置数据
		user_passwd_cache.set_info(userid,info);
	} 

	user_info_map.erase(key);
	return ;

}

bool Cuser_info_mgr::userinfo_check_existed(void* recvbuf )
{
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	return user_passwd_cache.record_existed(p_proto_header->id );
}

int Cuser_info_mgr::check_user_passwd_md5_two(void* recvbuf, uint32_t * p_gameflag )
{
	int ret=0;
	userid_t id;
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	id=p_proto_header->id;
	char *passwd;
	passwd=(char *)recvbuf+PROTO_HEADER_SIZE;
	stru_cache_info info={};
	stru_cache_info user_info;
	this->request_count++;//请求数
	stru_trans_key key(recvbuf);
	DEBUG_LOG("-insert----[%u][%u]",key.protoid,key.userid );

	if(user_passwd_cache.get_info(id, &info)){
		this->hit_count++;//命中数

		//对二次md5 进行验正
		if (!memcmp(passwd, info.passwd_md5_two,PASSWD_LEN)){
			//密码验证成功
			*p_gameflag=info.flag;			
			ret=SUCC;
		}else{
			this->passwd_err_count++;//密码出错
			user_info.flag=1;
			ret=CHECK_PASSWD_ERR;
		}
	}else{
		//借用来表示，缓存不在
		user_info.flag=0;
		ret=USER_ID_NOFIND_ERR;
	}


	if (ret==USER_ID_NOFIND_ERR ||
			( (ret==CHECK_PASSWD_ERR)&& this->check_db_passwd_flag==1)){
		//密码验证失败，并且设置成要DB check 
		//就到db中验证，而后如果成功则保存到缓存中
		//这里保存的是md5_two的值
		memcpy(user_info.passwd, passwd, PASSWD_LEN);
		user_info_map[key]=user_info;
	}

	return ret;
}


int Cuser_info_mgr::check_user_passwd(void* recvbuf, uint32_t * p_gameflag )
{
	int ret=0;
	userid_t id;
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	id=p_proto_header->id;
	char *passwd;
	passwd=(char *)recvbuf+PROTO_HEADER_SIZE;
	stru_cache_info info={};
	stru_cache_info user_info;
	this->request_count++;//请求数
	stru_trans_key key(recvbuf);
	DEBUG_LOG("-insert----[%u][%u]",key.protoid,key.userid );

	if(user_passwd_cache.get_info(id, &info) //找到了
		&&	memcmp(info.passwd, "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0" ,PASSWD_LEN)//并且passwd不为空
	  ){
		this->hit_count++;//命中数
		if (!memcmp(passwd, info.passwd,PASSWD_LEN)) //相等
		{
			//密码验证成功
			*p_gameflag=info.flag;			
			ret=SUCC;
		}else{
			this->passwd_err_count++;//密码出错
			//借用来表示，密码验正出错
			user_info.flag=1;
			ret=CHECK_PASSWD_ERR;
		}
	}else{
		DEBUG_LOG("nofind recode %u",id);
		//借用来表示，缓存不在
		user_info.flag=0;
		ret=USER_ID_NOFIND_ERR;
	}


	if (ret==USER_ID_NOFIND_ERR ||
			( (ret==CHECK_PASSWD_ERR)&& this->check_db_passwd_flag==1)){
		//密码验证失败，并且设置成要DB check 
		//就到db中验证，而后如果成功则保存到缓存中
		memcpy(user_info.passwd , passwd, PASSWD_LEN);
		user_info_map[key]=user_info;
	}
	return ret;
}

void Cuser_info_mgr::change_passwd_cmd(void* recvbuf)
{
	userid_t id;
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	id=p_proto_header->id;
	uint16_t cmd_id = p_proto_header->cmd_id;
	stru_trans_key key(recvbuf);
	char*pri_buf=(((char*)recvbuf)+PROTO_HEADER_SIZE);
	char passwd[PASSWD_LEN];
	
 	switch ( cmd_id )
	{
		case USERINFO_SET_PASSWD_EX_CMD:
			if (((userinfo_set_passwd_ex_in*)pri_buf)->passwd_type==1){//是登入密码
				memcpy (passwd, ((userinfo_set_passwd_ex_in*)pri_buf)->newpasswd,PASSWD_LEN);
				break;
			}else{
				//是支付密码直接返回
				return;
			}

		case USERINFO_SET_PASSWD_ONLY_CHECK_CHANGE_FLAG_CMD :
			if (((userinfo_set_passwd_only_check_change_flag_in*)pri_buf)->passwd_type==1){
				//是登入密码
				memcpy (passwd, ((userinfo_set_passwd_only_check_change_flag_in*)pri_buf)->
						newpasswd,PASSWD_LEN);
				break;
			}else{
				//是支付密码直接返回
				return;
			}


			break;
		case USERINFO_CHANGE_PASSWD:
			memcpy (passwd, ((userinfo_change_passwd_in*)pri_buf)->newpasswd, PASSWD_LEN);
			break;
		case USERINFO_SU_SET_PASSWD_CMD:
			memcpy (passwd, ((userinfo_su_set_passwd_in*)pri_buf)->passwd, PASSWD_LEN);
			break;
		case USERINFO_CHANGE_PASSWD_NOCHECK:
			memcpy (passwd, ((userinfo_change_passwd_nocheck_in*)pri_buf)->newpasswd, PASSWD_LEN);
			break;
		default :
			ERROR_LOG("ERR:change_passwd err cmd %04x",cmd_id  );
			return ;
			break;
	}
	


	stru_cache_info user_info;
	memcpy(user_info.passwd , passwd, PASSWD_LEN);
	user_info.flag = 0;
	user_passwd_map[key]=user_info;
	return ;	
}

void Cuser_info_mgr::userinfo_set_user_enable_flag(void* recvbuf)
{
	PROTO_HEADER * p_proto_header = (PROTO_HEADER *) recvbuf;	
	userid_t userid = p_proto_header->id;
	this->user_passwd_cache.remove_record(userid );
}


void Cuser_info_mgr::change_flag_cmd(void* recvbuf)
{
	stru_trans_key key(recvbuf);
	uint32_t flag = *((uint32_t*)((char *)recvbuf + PROTO_HEADER_SIZE));

	stru_cache_info user_info;
	user_info.flag=flag; 
	user_flag_map[key]= user_info;				
	return ;
}

void Cuser_info_mgr::userinfo_change_passwd_o(void* recvbuf)
{
	//更新 passwd
	userid_t userid;
	int32_t  ret = 0;	
	stru_trans_key key(recvbuf);
	PROTO_HEADER * p_proto_header = (PROTO_HEADER *) recvbuf;	
	userid = p_proto_header->id;
	ret = p_proto_header->result;	
	if (ret == SUCC) {	
		stru_cache_info  info ;
		if (!user_passwd_cache.get_info(userid, &info)) {			
			//没有找到记录
			user_passwd_map.erase(key);
			return ;
		}

		stru_cache_info info_tmp;
		std::map<stru_trans_key , stru_cache_info>::iterator it;
		it = user_passwd_map.find(key);
		if (it != user_passwd_map.end()) {
			info_tmp = it->second;
		}	else {			
			//没有找到记录
			ERROR_LOG("no user:[%d] passwd info in memory \n", userid);
			return ;
		}			

		memcpy(info.passwd, info_tmp.passwd, PASSWD_LEN); 
		user_passwd_cache.set_info(userid, info);
	} 

	user_passwd_map.erase(key);
	return ;
}

void Cuser_info_mgr::userinfo_add_game_o(void* recvbuf)
{
	userid_t userid;
	int32_t  ret = 0;	
	stru_trans_key key(recvbuf);
	PROTO_HEADER * p_proto_header = (PROTO_HEADER *) recvbuf;	
	userid = p_proto_header->id;
	ret = p_proto_header->result;	
	if (ret == 0) {	
		stru_cache_info info ;
		if (!user_passwd_cache.get_info(userid, &info)) {	
			user_flag_map.erase(key);
			//没有找到
			return ;
		}

		stru_cache_info info_tmp;
		std::map<stru_trans_key, stru_cache_info>::iterator it;
		it = user_flag_map.find(key);
		if (it != user_flag_map.end()){
			info_tmp = it->second;
		}	else{			
			ERROR_LOG("no user:[%u] flag info in memory \n", userid);
			return ;
		}			

		//输入的值不对
		if (info_tmp.flag<1 || info_tmp.flag>32 ) 
			return  ; 
		uint32_t gameflag_bit=(0x01<< (info_tmp.flag -1 ) );
		info.flag |=gameflag_bit; //
		user_passwd_cache.set_info(userid, info);
	} 
	user_flag_map.erase(key);
	
	return ;
}

void Cuser_info_mgr::userinfo_get_login_info_o( void* recvbuf )
{
	userid_t userid;
	int32_t  ret = 0;	
	PROTO_HEADER * p_proto_header = (PROTO_HEADER *) recvbuf;	
	userid = p_proto_header->id;
	ret = p_proto_header->result;	
	if  (ret==SUCC){
		userinfo_get_login_info_out * p_info =(userinfo_get_login_info_out*)RCVBUF_PRIVATE_POS;
		stru_cache_info item;
		item.flag=p_info->gameflag;
		memcpy (item.passwd,p_info->passwd,sizeof(p_info->passwd));
		this->user_passwd_cache.set_info(userid, item);	
	};
}

bool Cuser_info_mgr::deal_input_msg(void* recvbuf ,stru_proxy_interface_out *p_out )
{
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	int cmd_id=p_proto_header->cmd_id;
	int userid=p_proto_header->id;
	char sendbuf[100];int sendlen;
	switch (cmd_id){
	case USERINFO_LOGIN_BY_MD5_TWO_CMD: {////用户登入:密码是两次md5后的值
			DEBUG_LOG("USERINFO_LOGIN_BY_MD5_TWO_CMD");
			uint32_t gameflag;
			int ret=this->check_user_passwd_md5_two(recvbuf, &gameflag );
			if (ret==SUCC){//检查成功

				userinfo_log_with_stat_in *p_in=
					(userinfo_log_with_stat_in*)((char*)recvbuf+PROTO_HEADER_SIZE);

				//登入记录，udp 发出
				set_std_return_p(sendbuf,&sendlen,p_proto_header,0,SUCC,
						sizeof(stru_ip_history));
				((PROTO_HEADER*)sendbuf)->cmd_id=0xF106;
				stru_ip_history* p_ip_log=(stru_ip_history*)(sendbuf+PROTO_HEADER_SIZE);
				p_ip_log->userid=p_proto_header->id;
				p_ip_log->which_game=p_in->login_channel;
				p_ip_log->ip=p_in->ip;
				login_log_udp_sender.send(sendbuf,sendlen);
				INFO_LOG("check passwd: succ:%u",userid );

				//设置返回报文
				p_out->set_send_to_client_without_buf(SUCC,sizeof(userinfo_log_with_stat_out) );
				((userinfo_log_with_stat_out*)
					(p_out->send_client_private_buf))->gameflag=gameflag;
				return true;
			}else{
				if (ret==CHECK_PASSWD_ERR&& this->check_db_passwd_flag==0 ){
					p_out->set_send_to_client_without_buf(CHECK_PASSWD_ERR );
					INFO_LOG("check passwd: fail:%u",userid );
					return true;
		
				}
			}
			break;

		

		break;
		}
//---------------------------------------------------------------------------------------------
		case USERINFO_LOG_WITH_STAT: {
				uint32_t gameflag;
				int ret=this->check_user_passwd(recvbuf, &gameflag );
				if (ret==SUCC){//检查成功

					userinfo_log_with_stat_in *p_in=
						(userinfo_log_with_stat_in*)((char*)recvbuf+PROTO_HEADER_SIZE);

					//登入记录，udp 发出
					set_std_return_p(sendbuf,&sendlen,p_proto_header,0,SUCC,
							sizeof(stru_ip_history));
					((PROTO_HEADER*)sendbuf)->cmd_id=0xF106;
					stru_ip_history* p_ip_log=(stru_ip_history*)(sendbuf+PROTO_HEADER_SIZE);
					p_ip_log->userid=p_proto_header->id;
					p_ip_log->which_game=p_in->login_channel;
					p_ip_log->ip=p_in->ip;
					login_log_udp_sender.send(sendbuf,sendlen);
					INFO_LOG("check passwd: succ:%u",userid );

					//设置返回报文
					p_out->set_send_to_client_without_buf(SUCC,sizeof(userinfo_log_with_stat_out) );
					((userinfo_log_with_stat_out*)
					 	(p_out->send_client_private_buf))->gameflag=gameflag;
					return true;
				}else{
					if (ret==CHECK_PASSWD_ERR&& this->check_db_passwd_flag==0 ){
						p_out->set_send_to_client_without_buf(CHECK_PASSWD_ERR );
						INFO_LOG("check passwd: fail:%u",userid );
						return true;
			
					}
				}
				break;
			 }
//---------------------------------------------------------------------------------------------

		case USERINFO_CHECK_EXISTED:{
				if (this->userinfo_check_existed(recvbuf ))
				{	//是否其中有记录,如果有则返回存在，不然，到DB验正
					p_out->set_send_to_client_without_buf(SUCC);
					return true;
				}
				break;
			 }
		case USERINFO_DO_CACHE:{
				//设置对应的值
				userinfo_do_cache_in*p_in=
						(userinfo_do_cache_in*)((char*)recvbuf+PROTO_HEADER_SIZE);
				this->set_cache_arg(p_in);

				//设置返回报文
				p_out->set_send_to_client_without_buf(SUCC,sizeof(userinfo_do_cache_out) );
				userinfo_do_cache_out *p_cache=
					(userinfo_do_cache_out*)(p_out->send_client_private_buf);
				p_cache->start_time=this->start_time;
				p_cache->cur_cache_count=this->get_cache_size();
				p_cache->max_cache_count=this->get_max_cache_size();
				p_cache->del_count_once_over_max=
					this->user_passwd_cache.del_count_once_over_max;
				p_cache->diff_db_count=this->diff_db_count;
				p_cache->hit_count=this->hit_count;
				p_cache->request_count=this->request_count;
				p_cache->passwd_err_count=this->passwd_err_count;
				p_cache->check_db_passwd_flag=this->check_db_passwd_flag;

				p_cache->cur_user_info_map_count=this->user_info_map.size();
				p_cache->cur_user_flag_map_count=this->user_flag_map.size();
				p_cache->cur_user_passwd_map_count=this->user_passwd_map.size();

				return true;
				break;
			 }

		case USERINFO_REMOVE_CACHE_BY_LOGINTIME:{
				//p_proto_header->id 保存：删除几天之前的数据：单位:天
				this->remove_cache_by_logintime(p_proto_header->id);
				p_out->set_send_to_client_without_buf(SUCC );
				return true;
				break;
			 }
		
		case USERINFO_ADD_GAME:{//
				this->change_flag_cmd(recvbuf);
				break;
			}
		case USERINFO_SET_USER_ENABLE_FLAG:{//
				this->userinfo_set_user_enable_flag(recvbuf);
				break;
			}



		//修改密码的
		case USERINFO_SET_PASSWD_EX_CMD:
		case USERINFO_SET_PASSWD_ONLY_CHECK_CHANGE_FLAG_CMD :
		case USERINFO_CHANGE_PASSWD:
		case USERINFO_SU_SET_PASSWD_CMD:
		case USERINFO_CHANGE_PASSWD_NOCHECK:{
				this->change_passwd_cmd(recvbuf);
				break;			
			}
		default: break;
	}
	//没有处理
	return false;
}


void Cuser_info_mgr::deal_output_msg(void* recvbuf  )
{
	switch ( ((PROTO_HEADER *)recvbuf)->cmd_id ){
		case USERINFO_LOG_WITH_STAT:{
				this->userinfo_log_with_stat_o(recvbuf);
				break;
			 }
		case USERINFO_LOGIN_BY_MD5_TWO_CMD:{
				this->userinfo_login_by_md5_two_o(recvbuf);
				INFO_LOG("========");
				break;
			}

		case USERINFO_SET_PASSWD_EX_CMD:
		case USERINFO_SET_PASSWD_ONLY_CHECK_CHANGE_FLAG_CMD :
		case USERINFO_CHANGE_PASSWD:
		case USERINFO_SU_SET_PASSWD_CMD:
		case USERINFO_CHANGE_PASSWD_NOCHECK:{
				this->userinfo_change_passwd_o(recvbuf);
				break;			
			}
		case USERINFO_ADD_GAME: {
				this->userinfo_add_game_o(recvbuf);
				break;
			}	
		case USERINFO_GET_LOGIN_INFO: {
				this->userinfo_get_login_info_o(recvbuf);
				break;
			}	
		default: break;
	}
}
