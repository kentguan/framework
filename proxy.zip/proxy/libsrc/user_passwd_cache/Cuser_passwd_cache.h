/*
 * =====================================================================================
 *
 *       Filename:  Cuser_passwd_cache.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/08/2009 10:03:03 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jim (xcwen), jim@taomee.com
 *        Company:  taomee
 *
 * =====================================================================================
 */
#ifndef  Cuser_passwd_cache_incl
#define  Cuser_passwd_cache_incl
extern "C" {
#include <libtaomee/list.h>
#include <libtaomee/log.h>
#include <libtaomee/timer.h>

#include <async_serv/dll.h>
#include <async_serv/net_if.h>
#include <libtaomee/conf_parser/config.h>
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <map>
#include "proto_header.h"
#include "libtaomee++/utils/md5.h"
#define PASSWD_LEN 16

struct stru_cache_info{
	char 	passwd[PASSWD_LEN];
	char 	passwd_md5_two[PASSWD_LEN];
	uint32_t flag;
	uint32_t lastlogin_time;
}__attribute__((packed));


class Cuser_passwd_cache {
	private:
		std::map<userid_t, stru_cache_info > userid_info_map;
		MD5 md5;
	public:
		uint32_t max_cache_count; 
		uint32_t del_count_once_over_max; //一次删除多少个
		bool get_info(userid_t userid, stru_cache_info * p_info );
		bool set_info(userid_t userid, stru_cache_info &info );
		bool record_existed(userid_t userid );
		void remove_record(userid_t userid );
		uint32_t size( );
		//删除之前几天的缓存
		void remove_by_logintime( uint32_t remove_before_days);
		void remove_random(uint32_t userid);

	public:
		Cuser_passwd_cache();
		~Cuser_passwd_cache();

};

#endif

