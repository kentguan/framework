/*
 * =====================================================================================
 *
 *       Filename:  Cuser_info_mgr.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/08/2009 10:03:03 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jim (xcwen), jim@taomee.com
 *        Company:  taomee
 *
 * =====================================================================================
 */
#ifndef  Cuser_info_mgr_incl
#define  Cuser_info_mgr_incl
extern "C" {
#include <libtaomee/list.h>
#include <libtaomee/log.h>
#include <libtaomee/timer.h>

#include <async_serv/dll.h>
#include <async_serv/net_if.h>
#include <libtaomee/conf_parser/config.h>
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "libtaomee++/utils/tcpip.h"
#include "libtaomee++/utils/strings.hpp"

#include <map>
#include "proto_header.h"
#include "proxy_dll_interface.h"
#include "db_error.h"
#include "Cuser_passwd_cache.h"


#define USERINFO_CHECK_EXISTED 	0x0005
#define USERINFO_LOG_WITH_STAT  0x000C
#define USERINFO_CHANGE_PASSWD  0x0109
#define USERINFO_SU_SET_PASSWD_CMD 0x010A
#define USERINFO_CHANGE_PASSWD_NOCHECK   0x0140

//全能修改密码
#define USERINFO_SET_PASSWD_EX_CMD          (0x005B |NEED_UPDATE)

//全能设置密码，与 USERINFO_SET_CHANGE_PASSWD_FLAG_EX 配合使用
#define USERINFO_SET_PASSWD_ONLY_CHECK_CHANGE_FLAG_CMD  (0x005D |NEED_UPDATE)

//用户登入:密码是两次md5后的值
#define USERINFO_LOGIN_BY_MD5_TWO_CMD       (0x005F )


#define USERINFO_ADD_GAME 			0x0108
#define USERINFO_GET_LOGIN_INFO 			0x0091

//设置用户账号是否可用标志(冻结，解冻)  
#define USERINFO_SET_USER_ENABLE_FLAG 		0x0194

#define USERINFO_DO_CACHE 						0x01F0
#define USERINFO_REMOVE_CACHE_BY_LOGINTIME 		0x01F1

struct stru_passwd {
    char passwd[PASSWD_LEN];
}__attribute__((packed));

struct  userinfo_get_login_info_out{
    char        passwd[PASSWD_LEN];
    uint32_t    gameflag;
}__attribute__((packed));

struct  userinfo_set_passwd_ex_in{
    uint32_t passwd_type;
    uint32_t passwd_change_way;
    char    newpasswd[PASSWD_LEN];
}__attribute__((packed));
typedef stru_passwd userinfo_su_set_passwd_in ;

struct userinfo_change_passwd_in{
    char oldpasswd[PASSWD_LEN];
    char newpasswd[PASSWD_LEN];
}__attribute__((packed));

struct  stru_new_passwd{
    char newpasswd[PASSWD_LEN];
}__attribute__((packed));
typedef stru_new_passwd userinfo_change_passwd_nocheck_in;


typedef userinfo_set_passwd_ex_in userinfo_set_passwd_only_check_change_flag_in;


struct userinfo_log_with_stat_out{
	uint32_t gameflag;	
} __attribute__((packed));

struct  userinfo_log_with_stat_in{
    char passwd[PASSWD_LEN];
    uint32_t ip;
    uint32_t login_channel;
}__attribute__((packed));

struct stru_ip_history {    
    uint32_t userid;
    uint32_t which_game;
    uint32_t ip;
}__attribute__((packed));
struct userinfo_do_cache_in{    
    int32_t max_cache_count;//总个数
    int32_t del_count_once_over_max;//在超过最大值时，每次删除几个
    int32_t check_db_passwd_flag; //在检查密码出错时，是否要到DB中重新检查一遍
    int32_t clear_temp_map_flag; //清空临时用的三个map :=1 时
}__attribute__((packed));

struct  userinfo_login_by_md5_two_in{
    char passwd_md5_two[PASSWD_LEN];
    uint32_t ip;
    uint32_t login_channel;
}__attribute__((packed));

struct  userinfo_login_by_md5_two_out{
    uint32_t gameflag;
}__attribute__((packed));


struct userinfo_do_cache_out{    
    uint32_t start_time; 	//启动时间
    uint32_t cur_cache_count;//当前个数
    uint32_t max_cache_count;//总个数
    uint32_t del_count_once_over_max;//在超过最大值时，每次删除几个
    uint32_t check_db_passwd_flag;//在检查密码出错时，是否要到DB中重新检查一遍
    uint32_t diff_db_count; //和数据中不一致的个数
    uint32_t request_count; //请求数
    uint32_t hit_count; //命中数
    uint32_t passwd_err_count; //密码出错的个数
    uint32_t cur_user_info_map_count; //临时保存的用户信息个数
    uint32_t cur_user_flag_map_count; //临时保存的用户加入游戏个数
    uint32_t cur_user_passwd_map_count; //临时保存的用户修改密码个数
}__attribute__((packed));

struct stru_trans_key{
    uint32_t userid;//
    uint32_t protoid;//
    bool operator==(const stru_trans_key & ob)const{
        return (ob.userid== this->userid && ob.protoid== this->protoid);
    }
    //for map.find
    bool operator<(const stru_trans_key & ob)const{
		if (this->userid<ob.userid)	{
			return true;
		}
		if (this->userid==ob.userid ){
			return this->protoid<ob.protoid;
		}
		return false;
    }
	stru_trans_key(void* recvbuf )
	{
		PROTO_HEADER * p_header=(PROTO_HEADER *) recvbuf;	
		this->userid=p_header->id;	
		this->protoid=p_header->proto_id;	
	}
}__attribute__((packed));


class Cuser_info_mgr {

	private:
		uint32_t start_time;
		uint32_t diff_db_count;

	    uint32_t request_count; //请求数
	    uint32_t hit_count; //命中数
	    uint32_t passwd_err_count; //密码出错的个数
	    uint32_t check_db_passwd_flag; //在检查密码出错时，是否要到DB中重新检查一遍

		std::map<stru_trans_key , stru_cache_info> user_info_map;
		std::map<stru_trans_key , stru_cache_info> user_flag_map;
		std::map<stru_trans_key, stru_cache_info> user_passwd_map;
	
	private:
		Cuser_passwd_cache user_passwd_cache;
		Cudp_sender login_log_udp_sender;

	public:
		void userinfo_log_with_stat_o(void* recvbuf);
		int check_user_passwd(void* recvbuf,  uint32_t * p_gameflag);
		void change_passwd_cmd(void* recvbuf);
		void change_flag_cmd(void* recvbuf);
		void userinfo_change_passwd_o(void* recvbuf);
		void userinfo_add_game_o(void* recvbuf);
		bool userinfo_check_existed(void* recvbuf );
		void userinfo_get_login_info_o(void* recvbuf );
		int check_user_passwd_md5_two(void* recvbuf, uint32_t * p_gameflag );
		void userinfo_login_by_md5_two_o( void* recvbuf );
		void userinfo_set_user_enable_flag(void* recvbuf);


		uint32_t get_cache_size(){
			return this->user_passwd_cache.size();
		}

		uint32_t get_max_cache_size(){
			return this->user_passwd_cache.max_cache_count;
		}
		void set_cache_arg(userinfo_do_cache_in *p_in ){
			if (p_in->max_cache_count>0){
				this->user_passwd_cache.max_cache_count=p_in->max_cache_count;
			}
			if (p_in->del_count_once_over_max>0){
				this->user_passwd_cache.del_count_once_over_max=
					p_in->del_count_once_over_max;
			}
			if (p_in->check_db_passwd_flag!=-1){
				this->check_db_passwd_flag=p_in->check_db_passwd_flag;
			}

			if (p_in->clear_temp_map_flag==1){
				DEBUG_LOG("==CLEAR TMP MAP==");
				this->user_flag_map.clear();
				this->user_info_map.clear();
				this->user_passwd_map.clear();
			}

		}
		void remove_cache_by_logintime(uint32_t remove_before_days){
			this->user_passwd_cache.remove_by_logintime(remove_before_days );
		}
		//返回是否已经处理了
		bool deal_input_msg(void* recvbuf ,stru_proxy_interface_out *p_out );

		//处理一下返回数据
		void deal_output_msg(void* recvbuf  );

	public:
		Cuser_info_mgr() ;
	
		~Cuser_info_mgr() ;

};

#endif

