/*
 * =====================================================================================
 *
 *       Filename:  Cuser_passwd_cache.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/08/2009 10:02:52 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jim (xcwen), jim@taomee.com
 *        Company:  taomee
 *
 * =====================================================================================
 */
#include "Cuser_passwd_cache.h"

Cuser_passwd_cache::Cuser_passwd_cache()
{
	this->max_cache_count=config_get_intval("MAX_CACHE_COUNT", 10000000 );
	this->del_count_once_over_max=config_get_intval("DEL_COUNT_ONCE_OVER_MAX", 5000);
}


Cuser_passwd_cache::~Cuser_passwd_cache()
{

}

bool Cuser_passwd_cache::get_info(userid_t userid,stru_cache_info *p_info )
{
	std::map<userid_t,stru_cache_info>::iterator it;
	it = this->userid_info_map.find(userid);
	if (it != this->userid_info_map.end()){
		*p_info = it->second;
		it->second.lastlogin_time=time(NULL);//拉取时，设置最后时间
		return true;
	}
	return false;
}
inline void ASC2HEX_2_lower(char * dst, char * src,int len)
{   
    int hex;
    int i;
    int di;
    for(i=0;i<len;i++){
        hex=((unsigned char)src[i])>>4;
        di=i*2;
        dst[di]=hex<10?'0'+hex:'a'-10 +hex ;
        hex=((unsigned char)src[i])&0x0F;
        dst[di+1]=hex<10?'0'+hex:'a'-10 +hex ;
    }
    dst[len*2]=0;
}


bool Cuser_passwd_cache::set_info(userid_t userid,stru_cache_info &info )
{	
	
	info.lastlogin_time=time(NULL);
	if (memcmp(info.passwd,"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0", PASSWD_LEN)){
		//有设置passwd,计算出其md5 2
	    char hex_passwd[33]  ;
	    ASC2HEX_2_lower(hex_passwd,info.passwd, PASSWD_LEN );
		this->md5.reset();
		this->md5.update(hex_passwd);
		memcpy(info.passwd_md5_two,this->md5.digest(),PASSWD_LEN );
	}else{
		//只有设置md5 two 则不处理

	}
	this->userid_info_map[userid]=info;

	//LOG
	{
		char passwd_1[33],passwd_2[33];
	    ASC2HEX_2_lower(passwd_1 ,info.passwd, PASSWD_LEN );
	    ASC2HEX_2_lower(passwd_2 ,info.passwd_md5_two, PASSWD_LEN );
		DEBUG_LOG("CACHE userid:[%u] md5[%s] md5_two[%s]", userid,passwd_1,passwd_2 );
	}
			

	//个数超过
	if (this->userid_info_map.size()>this->max_cache_count){
		this->remove_random(userid );
	}

	return true;
}

bool  Cuser_passwd_cache:: record_existed(userid_t userid )
{
	return this->userid_info_map.find(userid)!=this->userid_info_map.end();
}

uint32_t Cuser_passwd_cache::size( )
{
	return this->userid_info_map.size();
}
void Cuser_passwd_cache::remove_record(userid_t userid )
{
	this->userid_info_map.erase(userid);
}

void Cuser_passwd_cache::remove_random(uint32_t userid)
{
	//找到一些超过两天没登入的删除。
	std::map<userid_t,stru_cache_info>::iterator it;


	//一小时前找到就删除
	uint32_t lastlogin_time_mix=time(NULL)-60*60;

	uint32_t do_count=0;

	//以下代码不要乱修改!
	for(it=this->userid_info_map.find(userid);it != this->userid_info_map.end();){
		if( it->second.lastlogin_time<lastlogin_time_mix) {
			this->userid_info_map.erase(it++);
		}else{
			it++;
		}

		do_count++;
		if (do_count>this->del_count_once_over_max ){
			break;		
		}
	}
	ERROR_LOG(" remove random cur%u:max:%u",this->userid_info_map.size(),this->max_cache_count );
}

void Cuser_passwd_cache::remove_by_logintime(uint32_t remove_before_days )
{

	uint32_t start_count=this->userid_info_map.size();	
	if (start_count< this->max_cache_count*0.8 ){
		//没有必要删除
		return;
	}
	//得到当前小时
	struct tm tm_tmp;
	time_t t=time(NULL);
	localtime_r(&t, &tm_tmp) ;
	int hour=tm_tmp.tm_hour;
	if (!(hour>=1 && hour<=3)){
		//这是一项耗时的工作得在1－4点处理，不然一概不理
		return;
	}


	if (remove_before_days<10 )
		remove_before_days=10;
	

	uint32_t lastlogin_time_mix=time(NULL)-60*60*24*remove_before_days;

	std::map<userid_t,stru_cache_info>::iterator it;
	//以下代码不要乱修改!
	for(it=this->userid_info_map.begin();it != this->userid_info_map.end();){
		if( it->second.lastlogin_time<lastlogin_time_mix) {
			this->userid_info_map.erase(it++);
		}else{
			it++;
		}
	}

	uint32_t end_count=this->userid_info_map.size();	
	ERROR_LOG("REMOVE ON TIME: start:%u,end:%u,remove:%u",
			start_count,end_count,start_count-end_count );

}
