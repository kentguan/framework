/*
 * =====================================================================================
 *
 *       Filename:  Csend_log.h
 *
 *    Description: 发送修改记录 ,用于客服查看
 *
 *        Version:  1.0
 *        Created:  04/08/2009 10:03:03 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jim (xcwen), jim@taomee.com
 *        Company:  taomee
 *
 * =====================================================================================
 */
#ifndef  CSEND_LOG_INCL
#define  CSEND_LOG_INCL
extern "C" {
#include <libtaomee/list.h>
#include <libtaomee/log.h>
#include <libtaomee/timer.h>

#include <async_serv/dll.h>
#include <async_serv/net_if.h>
#include <libtaomee/conf_parser/config.h>
}


#include "proto_header.h"
#include "db_error.h"
#include "tcpip.h"
/* 
 * @brief 发送修改记录的类
 */
struct stru_log_item{
	uint32_t type;
	uint32_t cmdid;
	uint32_t adminid;
	uint32_t userid;
	int32_t v1;
	int32_t v2;
	int32_t v3;
} __attribute__((packed));

class Csend_log {
	private:
		int log_fd;
		struct  sockaddr_in log_addr;
	public:
		Csend_log();
		int sendmsg ( char * recvbuf ,uint32_t adminid  );
		int send(stru_log_item *p_item );
};

#endif
