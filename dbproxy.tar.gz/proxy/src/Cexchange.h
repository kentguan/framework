/*
 * =====================================================================================
 *
 *       Filename:  Cexchange.h
 *
 *    Description: 	由于proxy 是异步的，所以需要保存协议的相关信息，以便正确返回
 *
 *        Version:  1.0
 *        Created:  2009年03月10日 10时49分47秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jim (xcwen), jim@taomee.com
 *        Company:  taomee
 *
 * =====================================================================================
 */

#include <stdio.h> 
#include <stdlib.h>
#include <string.h> 
//#include "tcpip.h"
#include <unistd.h>
#include "proto_header.h" 
#include "db_error_base.h" 
extern "C" {
#include <libtaomee/log.h>
#include <libtaomee/timer.h>
#include <async_serv/net_if.h>
#include <assert.h>
}

#include <map>
#include <set>
#include "dll_init.h" 

#ifndef  CEXCHANGE_INC
#define  CEXCHANGE_INC


struct stru_exchange{
	bool isused;//是否处于使用状态:
	uint32_t add_time;//加入时的时间
	stru_client_info c_item;
};



#define  EXCHANGE_ITEM_COUNT 655350  
#define  CLIENTFD_MAX 20000 
//protoid 交换列表
class Cexchange
{
  protected:
	//交换列表
	stru_exchange *p_list;	
	//当前处理到的id[0---EXCHANGE_ITEM_COUNT-1]
	uint32_t curid;
	//当前超时处理到的位置
	uint32_t cur_timeout_id;

	//返回值：SUCC , FAIL
	//p_id 为 所在的索引
	//pp_item:数据指针，返回后直接在其中赋值
	//返回值为FAIL:时，意味着之前有一条报文没有返回,
	//
	//返回值为SUCC:
	//内容保存在p_id(item所在的列表中的index),pp_item(指向item的空间,其内容未赋值);
	//会将其使用状态(used)设置为true
	int add( int client_fd, uint32_t *p_id,  stru_client_info ** pp_item);

	inline void  set_used(uint32_t id, int client_fd){
		this->p_list[this->curid].isused=true;
		DEBUG_LOG("used:%u",this->curid);
		this->p_list[this->curid].add_time=get_now_tv()->tv_sec  ;
		//将指针清空
		this->p_list[this->curid].c_item.pri_buf.state=0;//状态为0
		this->p_list[this->curid].c_item.pri_buf.p_ex_buf=NULL;
		assert(client_fd<CLIENTFD_MAX );
		this->fd_protoid_set[client_fd].insert(id );
	}



  public:
    Cexchange();  /* constructor */

	//加入列表，不如失败，则尝试下一个
	void add_always_succ( int client_fd, uint32_t *p_id,  stru_client_info ** pp_item);

	//通过索引id得到item
	//返回值：SUCC , FAIL
	//pp_item 为返回 item数据 
	//FAIL:表示这个交换已不存在,因为是DB超时,返回后一般不处理
	//会将其使用状态(used)设置为false
	int  get(uint32_t id,userid_t userid, stru_client_info ** pp_item );


	//客户端fd=> protoid_list
	std::set< uint32_t >  fd_protoid_set[ CLIENTFD_MAX];
	//通过客户端fd 清空相关列表
	int clear_by_client_fd(int client_fd );

	inline void  set_nouse(uint32_t id){
		DEBUG_LOG("unused:%u",this->curid);
		this->p_list[id].isused=false;//此时不清空加入时间(add_time)，在处理超时报文时使用
		//得到id
		int client_fd= this->p_list[id].c_item.p_client->fd;
		assert(client_fd<CLIENTFD_MAX );
		this->fd_protoid_set[client_fd].erase(id);
	}
	//<=last_time则为超时
	void do_timeout_pkg(uint32_t last_time);

};
#endif   /* ----- #ifndef CEXCHANGE_INC  ----- */
