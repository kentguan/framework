/*
 * =====================================================================================
 *
 *       Filename:  Croute.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2008年01月12日 12时32分48秒 CST
 *       Revision:  none
 *       Compiler:  gcc
 *         Author:  xcwen (xcwen), xcwenn@gmail.com
 *        Company:  TAOMEE
 * 		
 * 		------------------------------------------------------------
 * 		view configure:
 * 			VIM:  set tabstop=4 
 * 		
 * =====================================================================================
 */
#include "Cnew_route.h"
#include "db_error_base.h"
#include <errno.h>
#include <libxml/tree.h>
#define DECODE_XML_PROP(cur, prop, str) \
    str = xmlGetProp(cur, (xmlChar*)prop);  \
if (!str) ERROR_RETURN (("xml parse error: prop=%s", prop), -1)

#define DECODE_XML_PROP_DEFAULT(cur, prop, str ) \
    str = xmlGetProp(cur, (xmlChar*)prop);  
    
    

#define DECODE_XML_PROP_INT(v, cur, prop) \
        do { \
            xmlChar *str; \
            DECODE_XML_PROP(cur, prop, str); \
            v = atoi ((const char*)str); \
            xmlFree (str); \
        } while (0)

#define DECODE_XML_PROP_EX(cur, prop, str) \
    str = xmlGetProp(cur, (xmlChar*)prop);  \

#define DECODE_XML_PROP_INT_DEFAULT(v, cur, prop,def) \
        do { \
            xmlChar *str; \
            DECODE_XML_PROP_EX(cur, prop, str); \
            if (str){\
                v = atoi ((const char*)str); \
                xmlFree (str); \
            }else{\
                v = def; \
            }\
        } while (0)
#define DECODE_XML_PROP_HEX_DEFAULT(v, cur, prop,def) \
        do { \
            xmlChar *str; \
            DECODE_XML_PROP_EX(cur, prop, str); \
            if (str){\
                 sscanf (((const char*)str) , "%x", &(v));\
                xmlFree (str); \
            }else{\
                v = def; \
            }\
        } while (0)


#define DECODE_XML_PROP_STR(v, cur, prop) \
        do { \
            xmlChar *str; \
            DECODE_XML_PROP(cur, prop, str); \
            strncpy (v, (const char*)str, sizeof (v) - 1); \
            v[sizeof(v) - 1] = '\0'; \
            xmlFree (str); \
        } while (0)
#define DECODE_XML_PROP_STR_DEFAULT(v, cur, prop) \
        do { \
            xmlChar *str; \
            DECODE_XML_PROP_DEFAULT(cur, prop, str); \
			if (str){\
				strncpy (v, (const char*)str, sizeof (v) - 1); \
				v[sizeof(v) - 1] = '\0'; \
				xmlFree (str); \
			}\
			v[0]='\0';\
        } while (0)




Cnew_route::Cnew_route ( char * config_xml)
{
	this->connect_null.ip[0]='\0';
	this->connect_null.port=0;
	this->connect_null.socketfd=-1;
	this->connect_null.last_fail_time=0;
	this->connect_null.last_succ_time=0;

	if (!this->reinit_route(config_xml)){
		boot_log(-1,0,"PROXY load route.xml err");
		exit(1);
	}
}  /* -----  end of method Croute::Croute  (constructor)  ----- */




int Cnew_route::get_socketfd(uint16_t cmdid,uint32_t id)
{
	int socketid;
	int  route_index=this->get_route_conf_index(GET_ROUTE(cmdid),id );
	if (route_index==-1) return -1;
	stru_route_cfg *p_route_cfg=&(this->route_cfg_list[route_index]);	
	
	conn_info_t* p_main_connect;
	if (p_route_cfg->main_conn_index !=-1 ){
		p_main_connect=&this->connect_cfg_list[p_route_cfg->main_conn_index];
	}else{
		p_main_connect=&this->connect_null;
	}

	conn_info_t* p_bak_connect;
	if (p_route_cfg->bak_conn_index!=-1 ){
		p_bak_connect=&this->connect_cfg_list[p_route_cfg->bak_conn_index];
	}else{
		p_bak_connect=&this->connect_null;
	}
	


	switch ( p_route_cfg->opt_type )
	{

		case OPT_BACK_NOUSED :
			return  p_main_connect->get_socketfd();
			break;

		case OPT_BACK_READ:
			if (cmdid& NEED_UPDATE ){
				socketid=p_main_connect->get_socketfd();
			}else{
				socketid=p_bak_connect->get_socketfd();
				if (socketid==-1){
					socketid=p_main_connect->get_socketfd();
				}
			}
			return socketid;
			break;

		case OPT_BACK_RW:
			if (cmdid& NEED_UPDATE ){
				socketid=p_main_connect->get_socketfd();
				if (socketid==-1){
					socketid=p_bak_connect->get_socketfd();
				}
			}else{
				socketid=p_bak_connect->get_socketfd();
				if (socketid==-1){
					socketid=p_main_connect->get_socketfd();
				}
			}
			return socketid;

		case OPT_BACK_USE_ON_MAIN_CLOSE:
			socketid=p_main_connect->get_socketfd();
			if (socketid==-1){
				socketid=p_bak_connect->get_socketfd();
			}
			return socketid;
		default :
			break;
	}

	return -1;
}

int  Cnew_route:: get_route_conf_index(uint32_t route_type,uint32_t id )
{

 	std::map<uint32_t , stru_route_item >::iterator  it;
	it=this->route_index_map.find(route_type );
	if(it!=this->route_index_map.end() ){
		return (it->second.route_startid+ id% it->second.db_type);
	}else{
		return -1;
	}
}


int  Cnew_route::add_connect_cfg( char * ip, uint16_t port  )
{
	for (uint32_t i=0;i<this->connect_cfg_list.size();i++ ){
		if (strcmp( this->connect_cfg_list[i].ip,ip)==0 
				&& this->connect_cfg_list[i].port==port ){
			return i;
		}
	}
	//没有找到，则加入
	conn_info_t item={};
	item.socketfd=-1;
	strncpy(item.ip,ip,sizeof(item.ip)-1);
	item.port=port;
	this->connect_cfg_list.push_back(item );

	//返回最后一个^=^
	return this->connect_cfg_list.size()-1;
}
int Cnew_route::set_close_by_fd(int fd )
{
	for (uint32_t i=0;i<this->connect_cfg_list.size();i++){
		if(this->connect_cfg_list[i].socketfd==fd ){
			this->connect_cfg_list[i].socketfd=-1;
			return SUCC;
		}
	}
	return  FAIL;
}

//重置连接:不管是主还是备都断开，重连
int Cnew_route:: reset_socket( uint16_t cmdid, uint32_t id )
{
	int  route_index=get_route_conf_index(GET_ROUTE(cmdid),id);
	DEBUG_LOG("route_index:%d",route_index );
	if (route_index==-1) return -1;

	stru_route_cfg *p_route_cfg=&(this->route_cfg_list[route_index]);	

	//重置主连接
	if (p_route_cfg->main_conn_index !=-1){
		conn_info_t* p_main_connect=&this->connect_cfg_list[p_route_cfg->main_conn_index];
		if (p_main_connect->socketfd!=-1 ){
			DEBUG_LOG("3 PROXY CLOSE FD=%d  ",p_main_connect->socketfd  );
			close(p_main_connect->socketfd);
			p_main_connect->socketfd=-1;
		}
	}

	//重置备份连接
	if (p_route_cfg->bak_conn_index!=-1){
		conn_info_t* p_bak_connect=&this->connect_cfg_list[p_route_cfg->bak_conn_index];
		if (p_bak_connect->socketfd!=-1 ){
			DEBUG_LOG("2 PROXY CLOSE FD=%d  ",p_bak_connect->socketfd  );
			close(p_bak_connect->socketfd);
			p_bak_connect->socketfd=-1;
		}
	}

	return  this->get_socketfd(cmdid,id);
}
int Cnew_route::send_data(void* recvbuf )
{
	int ret=0;
	int  net_errno=0;
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	uint16_t cmdid=p_proto_header->cmd_id;


	int socketfd=0;
	socketfd= this->get_socketfd( cmdid , p_proto_header->id );
	//
	if (socketfd>0){//有socket 可用
		ret= net_send(socketfd,recvbuf, p_proto_header->proto_length );
		net_errno=errno;
	}else{
		ret=-1;
	}

	if (ret== -1 ){
		//防止DB服务器重启，重置连接
	 	DEBUG_LOG("net err cmdid[%04X] uid[%u] , fd[%d]    errno want[%d]  [%d][%s]re connect \n",
			 p_proto_header->cmd_id,p_proto_header->id, socketfd,EBADF ,
			 net_errno,strerror(net_errno) );	
		socketfd=this->reset_socket(cmdid,p_proto_header->id);
			
 		DEBUG_LOG("re send data\n");	
		if (socketfd>0){
			ret=net_send (socketfd,recvbuf,p_proto_header->proto_length );
		}
	}
	return ret;
}


bool Cnew_route::reinit_route( char * config_xml )
{
	if(!this->reset_xml_conf(config_xml )){
		return false;
	}


	
	uint32_t cur_index=0;
	//route_index_map	
	for(uint32_t i=0;i<this->xml_route_item_list.size();i++){
		Cxml_route_item *p_item=&(this->xml_route_item_list[i]);
		stru_route_item route_item;
		route_item.db_type=p_item->db_type;
		route_item.route_startid=cur_index;
		cur_index+=route_item.db_type;
		for(uint32_t cmd_j=0;cmd_j<p_item->cmdid_list.size();cmd_j++ ){
			uint32_t cmdid=p_item->cmdid_list[cmd_j];
			route_item.cmdid=cmdid;
			this->route_index_map[ GET_ROUTE(cmdid ) ]=route_item;
		}

	}

	//route_cfg_list	
	for(uint32_t i=0;i<this->xml_route_item_list.size();i++){
		Cxml_route_item *p_item=&(this->xml_route_item_list[i]);

		for(uint32_t ip_j=0;ip_j<p_item->db_connect_item_list.size();ip_j++ ){
			Cdb_connect_item* p_db_connect_item=&(p_item->db_connect_item_list[ip_j]);
			//设置
			for (uint32_t db_index=p_db_connect_item->db_startid ;
					db_index<=p_db_connect_item->db_endid ;db_index++) {
				int route_index=this->get_route_conf_index(GET_ROUTE(p_item->cmdid_list[0]) ,db_index);
				if (route_index<0 ){
        			ERROR_RETURN(( "ERROR : SYSERR cmdid=%u  ",p_item->cmdid_list[0] ), -1);
				}
				//不够,则加到够
				while (this->route_cfg_list.size()<=(uint32_t)route_index ){
					stru_route_cfg route_item;
					route_item.bak_conn_index=-1;
					route_item.main_conn_index=-1;
					route_item.opt_type=OPT_BACK_NOUSED;
					this->route_cfg_list.push_back(route_item);
				}

				stru_route_cfg *p_route_cfg_item=&(this->route_cfg_list[route_index]);	

				p_route_cfg_item->opt_type=(enum enum_connect_opt_type )p_db_connect_item->opt_type  ;

				//得到联接
				int32_t main_connect_index=this->add_connect_cfg(
						p_db_connect_item->ip,p_db_connect_item->port );		
				int32_t bak_connect_index=this->add_connect_cfg( 
						p_db_connect_item->bak_ip,p_db_connect_item->bak_port );		

				//设置主连接
				if (p_route_cfg_item ->main_conn_index!=main_connect_index){
					if (p_route_cfg_item->main_conn_index==-1){
						DEBUG_LOG("main config id[%d],new[%s][%d]",
								main_connect_index, 
								p_db_connect_item->ip,
								p_db_connect_item->port	
								);
					}else{
						DEBUG_LOG("main config_diff id[%d],old[%s][%d],new[%s][%d]",
								main_connect_index, 
								this->connect_cfg_list[ p_route_cfg_item->main_conn_index].ip,
								this->connect_cfg_list[ p_route_cfg_item->main_conn_index].port,
								p_db_connect_item->ip,
								p_db_connect_item->port	
								);
					}
				}



				p_route_cfg_item->main_conn_index=main_connect_index;
				//设置备份连接
				if (p_route_cfg_item->bak_conn_index!=bak_connect_index){
					if (p_route_cfg_item->bak_conn_index==-1){
						if (p_db_connect_item->bak_port!=0){
							DEBUG_LOG("bak config id[%d],new[%s][%d]",
								bak_connect_index, 
								p_db_connect_item->bak_ip,
								p_db_connect_item->bak_port	
								);
						}
					}else{
						DEBUG_LOG("bak config_diff id[%d],old[%s][%d],new[%s][%d]",
								bak_connect_index, 
								this->connect_cfg_list[ p_route_cfg_item->bak_conn_index].ip,
								this->connect_cfg_list[ p_route_cfg_item->bak_conn_index].port,
								p_db_connect_item->bak_ip,
								p_db_connect_item->bak_port	
								);
					}
				}
				p_route_cfg_item->bak_conn_index=bak_connect_index;

			}



		}

	}

	return true;
}

bool Cnew_route::reset_xml_conf( char*  config_xml )
{
	//清空原有配置
	this->xml_route_item_list.clear();

    xmlDocPtr doc = xmlReadFile(config_xml ,NULL, XML_PARSE_NOBLANKS);
    if (!doc) {
        ERROR_RETURN(("Failed to Load %s",config_xml ), false);
    }

    xmlNodePtr cur = xmlDocGetRootElement(doc);
    if (!cur) {
        KERROR_LOG(0, "xmlDocGetRootElement error");
    	xmlFreeDoc(doc);
    }

	cur = cur->xmlChildrenNode;
	//加载配置
    while (cur) {
        if (!xmlStrcmp(cur->name, (const xmlChar*)"route_item")) {
            Cxml_route_item xml_route_item ;
            DECODE_XML_PROP_INT( xml_route_item.db_type, cur, "db_type");
			if (!(xml_route_item.db_type ==1 
						|| xml_route_item.db_type ==10 
						|| xml_route_item.db_type ==100 )){
        		ERROR_RETURN(( "ERROR :XML  db_type=%u ", xml_route_item.db_type), false);
			}
            xmlNodePtr chl = cur->xmlChildrenNode;
            while (chl) {
				//命令号
                if (!xmlStrcmp(chl->name, (const xmlChar *)"cmd_bind")) {
            		xmlNodePtr ch3 = chl->xmlChildrenNode;
					while(ch3 ){
						if (!xmlStrcmp(ch3->name, (const xmlChar *)"item")) {
							uint32_t cmdid=0;
							DECODE_XML_PROP_HEX_DEFAULT(cmdid , ch3 , "cmdid",0);
							if ( cmdid==0 ){
								char buf[10];
								DECODE_XML_PROP_STR(buf, ch3, "cmdid" );
								if (! strcmp(buf,"0x0000" ) ){
									//正常,
								}else{
									ERROR_RETURN(( "ERROR :XML  db_type=%u, cmdid=%s ", xml_route_item.db_type,buf ), false );
								}
							}
							xml_route_item.cmdid_list.push_back(cmdid );
						}
                		ch3= ch3->next;
					}
                }
				//ip配置
                if (!xmlStrcmp(chl->name, (const xmlChar *)"ip_bind")) {
            		xmlNodePtr ch3 = chl->xmlChildrenNode;
					while(ch3 ){
						if (!xmlStrcmp(ch3->name, (const xmlChar *)"item")) {
								Cdb_connect_item db_connect_item;
								DECODE_XML_PROP_INT_DEFAULT(db_connect_item.db_startid ,ch3, "db_startid",0);
								DECODE_XML_PROP_INT_DEFAULT(db_connect_item.db_endid,ch3, "db_endid",0 );
								DECODE_XML_PROP_STR(db_connect_item.ip,ch3, "ip" );
								DECODE_XML_PROP_INT_DEFAULT(db_connect_item.port,ch3, "port",0 );

								DECODE_XML_PROP_STR_DEFAULT(db_connect_item.bak_ip,ch3, "bak_ip" );
								DECODE_XML_PROP_INT_DEFAULT(db_connect_item.bak_port,ch3, "bak_port",0 );
								DECODE_XML_PROP_INT_DEFAULT(db_connect_item.opt_type,ch3, "opt_type",0 );
								xml_route_item.db_connect_item_list.push_back(db_connect_item );
								DEBUG_LOG("=====%s,%u",db_connect_item.ip, db_connect_item.port );
						}
                		ch3= ch3->next;
					}

                }

                chl= chl->next;
            }
			if (xml_route_item.cmdid_list.size() ==0 ){
        		ERROR_RETURN(( "ERROR :XML  db_type=%u, cmd_bind :count=0", xml_route_item.db_type), false);
			}
			this->xml_route_item_list.push_back( xml_route_item);
        }
        cur = cur->next;
	}
	
    xmlFreeDoc(doc);
	//处理完毕
	
	return true;
}
