/*
 * =====================================================================================
 * 
 *       Filename:  Croute.h
 * 
 *    Description:  
 * 
 *        Version:  1.0
 *        Created:  2008年01月12日 12时32分50秒 CST
 *       Revision:  none
 *       Compiler:  gcc
 * 
 *         Author:  xcwen (xcwen), xcwenn@gmail.com
 *        Company:  TAOMEE
 *
 *      ------------------------------------------------------------
 *      view configure:
 *          VIM:  set tabstop=4  
 * 
 * =====================================================================================
 */

#ifndef  Cnew_ROUTE_INC
#define  Cnew_ROUTE_INC
#include "proto_header.h"
#include "proxy_route.h"
/*
 * =====================================================================================
 *        Class:  Croute
 *  Description:  
 * =====================================================================================
 */

//#define CONN_INFO_COUNT (sizeof(struct route_conf)/sizeof(struct conn_info) )
#include <stdio.h> 
#include <stdlib.h>
#include <string.h> 
//#include "tcpip.h"
#include <unistd.h>

extern "C" {
#include <libtaomee/log.h>
#include <async_serv/net_if.h>
}
#include <vector>
#include <map>



typedef struct conn_info{
	uint32_t last_succ_time;//最后一次连接成功时间
	uint32_t last_fail_time;//最后一次连接失败时间
	char ip[16];
	u_short port;
	int socketfd;//>0:正常fd, -1:连接失败

	inline int connect(){
		DEBUG_LOG("reset socket :open socket[%s][%d]\n", ip,port);
		if (this->port==0){//没有配置
			return -1;	
		}
		if( this->socketfd==-1 && time(NULL)-this->last_fail_time<60 ){
			//连接失败时间小于设定时间,直接返回,不重连
			DEBUG_LOG("failtime <60 :fail,return -1[%u][%u] ", uint32_t (time(NULL)),uint32_t (this->last_fail_time));
			return -1;
		}
		//不管怎样,关闭原有连接
		if (this->socketfd!=-1) {
			DEBUG_LOG(" 1 PROXY CLOSE FD=%d  ",this->socketfd  );
			close(this->socketfd);
		}

		/*得到该连接的 IP ,port*/
		DEBUG_LOG("reset socket :open socket[%s][%d]\n", ip,port);
		uint32_t open_time=time(NULL);
			
		this->socketfd=connect_to_svr (ip,port,65535, 1);	
		if (this->socketfd == -1){
			uint32_t now=time(NULL);	
			if (now-open_time>=1){
				//连接超时
				this->last_fail_time=now;
			} else{//没有超时，但还是连不上，则5秒后重连
				this->last_fail_time=now-60+5;
			}
			DEBUG_LOG("reset socket error: open socket[%s][%d]\n", ip,port);
		}else{//连接成功
			this->last_fail_time=0;
		}
		return this->socketfd;
	}

	inline  int get_socketfd(){
		if (this->socketfd!=-1){
			return this->socketfd;
		}else{
			return this->connect();
		}
	}
} conn_info_t;


//连接如何使用主连接和备份连接
enum enum_connect_opt_type{
	OPT_BACK_NOUSED=0,//不使用备份连接
	OPT_BACK_RW=1, 	//备份连接可读写
	OPT_BACK_READ=2,	//备份连接只读，不可写
	OPT_BACK_USE_ON_MAIN_CLOSE=3,	//在主联接不能用时才使用 备份连接
};


struct stru_route_cfg{
	enum_connect_opt_type opt_type;	
	int32_t main_conn_index;
	int32_t bak_conn_index;
};

struct stru_route_item{
	//分库类型:1,10,100,按userid尾数
	uint32_t db_type;
	uint32_t cmdid;
	uint32_t route_startid;
};
class Cdb_connect_item{
	public:
	uint32_t db_startid;
	uint32_t db_endid;
	uint32_t opt_type;
	char ip[16];
	uint16_t port;
	char bak_ip[16];
	uint16_t bak_port;
};




class Cxml_route_item{
	public:
	//分库类型:1,10,100,按userid尾数
	uint32_t db_type;
	//要分发的命令列表
	std::vector<uint32_t> cmdid_list; 
	//
	std::vector<Cdb_connect_item> db_connect_item_list; 

};





class Cnew_route
{
  public:
    Cnew_route ( char * config_xml ); 
    virtual ~Cnew_route () {
	}	
	bool reinit_route( char * config_xml);

	int set_close_by_fd(int fd );
	int send_data(void* recvbuf );

  protected:

		//重置连接socket
		int reset_socket( uint16_t cmdid,uint32_t id );
		
		int get_route_conf_index( 
			uint32_t route_type,uint32_t id );
		

		int get_socketfd(uint16_t cmdid,uint32_t id);
		int  add_connect_cfg( char * ip, uint16_t port  );
		bool reset_xml_conf( char*  config_xml );
			
  private:
	//xml里的数据
 	std::vector<Cxml_route_item>  xml_route_item_list;

	//用于保存,每个路由对应的路由配置中的index
 	std::map<uint32_t , stru_route_item > route_index_map;

	//路由配置
 	std::vector<stru_route_cfg> route_cfg_list;
	//连接配置
	std::vector<conn_info_t> connect_cfg_list ;
	 conn_info_t connect_null;
	
}; 
#endif   
