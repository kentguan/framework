/*
 * =====================================================================================
 *
 *	   Filename:  dll_interface.cpp
 *
 *	Description:  
 *
 *		Version:  1.0
 *		Created:  03/08/2010 02:52:29 PM
 *	   Revision:  none
 *	   Compiler:  gcc
 *
 *		 Author:  jim (xcwen), jim@taomee.com
 *		Company:  taomee
 *
 * =====================================================================================
 */
#include "proxy_dll_interface.h"
#include "Cuser_info_mgr.h"
extern "C" {
#include <libtaomee/log.h>
}

//密码缓存
Cuser_info_mgr *user_info_mgr=NULL;
stru_lib_info g_lib_info={
	"user passwd cache ",
	"20100621",
};

void proxy_get_lib_info(stru_lib_info *p_out )
{
 	*p_out=g_lib_info;
}
//程序开始启动时调用
int proxy_init_service ()
{
	user_info_mgr = new Cuser_info_mgr();
	return 0;
}
//收到客户端报文时调用
//返回－1：表示该报文这需要proxy继续往下传。
//0:已经处理完毕，proxy不再处理
int proxy_process_client_cmd(char* recvbuf,int recvlen,stru_client_info * p_client_info , 
	          stru_proxy_interface_out *p_out )
{

	if (user_info_mgr->deal_input_msg(recvbuf,p_out)){//处理成功了
		return SUCC;
	}
	return -1;
}
//收到后端报文（一般是DBSER）时调用,
//返回－1：表示该报文这需要proxy继续往下传。
//0:已经处理完毕，proxy不再处理
int proxy_process_serv_return(char* recvbuf,int recvlen,stru_pri_buf * p_pri_buf ,
	          stru_proxy_interface_out *p_out  	)
{
	user_info_mgr->deal_output_msg(recvbuf);
	return -1;
}

//程序终止时调用
int proxy_fini_service (){
	return 0;
}

