/*
 * =====================================================================================
 *
 *       Filename:  Csend_log.cpp
 *
 *    Description:  通过UDP发送米米修改记录和密码修改记录
 *
 *        Version:  1.0
 *        Created:  04/08/2009 10:02:52 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jim (xcwen), jim@taomee.com
 *        Company:  taomee
 *
 * =====================================================================================
 */
#include "Csend_log.h"
#include "proxy_dll_interface.h"

//设置装扮
#define USER_SET_ATTIRE_EX_CMD          (0x101A | NEED_UPDATE)


struct  user_set_attire_ex_in{
	uint32_t		attireid;
	uint32_t		usedcount; 
	uint32_t		chestcount; 
	uint32_t		count;
} __attribute__((packed));


#define SU_CHANGE_CMD                   (0xA002| NEED_UPDATE)
struct  su_change_in {
        userid_t userid;
        uint32_t attrid;
        int32_t  changvalue;
        int32_t  reason;
} __attribute__((packed));

//增加物品
#define USER_ADD_ATTIRE_CMD             (0x101C | NEED_UPDATE)
struct    add_attire{
        uint32_t    attiretype;/*装扮0,小屋1*/
        uint32_t    attireid;
        uint32_t    count;
        uint32_t    maxcount;
} __attribute__((packed));
typedef add_attire  user_add_attire_in;


//卖物品
#define USER_SALE_ATTIRE_CMD            (0x1017 | NEED_UPDATE)

struct  user_buy_attire_by_xiaomee_in{
    add_attire      attire_item;
    uint32_t        usexiaomee;
} __attribute__((packed));

typedef user_buy_attire_by_xiaomee_in   user_sale_attire_in;

//PP
#define PP_CHANGE_XIAOMEE_CMD               (0x180B |NEED_UPDATE)
struct  pp_change_xiaomee_in{
    int32_t change_value;
    uint32_t is_add_xiaomee_day;
}__attribute__((packed));
//派派:设置_EX
#define PP_ATTIRE_SET_EX_CMD                (0x1849 |NEED_UPDATE)
struct stru_attire_property{
    uint32_t    attireid ;
    uint32_t    usedcount;
    uint32_t    count;
    uint32_t    duetime;
} __attribute__((packed));
typedef stru_attire_property pp_attire_set_ex_in;
//派派:小屋：购买物品
#define PP_HOME_BUY_ATTIRE_CMD              (0x1855 |NEED_UPDATE)
struct  pp_home_buy_attire_in{
    uint32_t   attireid;
    uint32_t   addcount;
    uint32_t   maxcount;
    uint32_t   usexiaomee;
}__attribute__((packed));

//派派:小屋：卖物品
#define PP_HOME_ATTIRE_SALE_CMD             (0x1856 |NEED_UPDATE)
struct  pp_attire_sale_in{
    uint32_t   attireid;
    uint32_t   count;
    uint32_t   xiaomee;
    uint32_t   is_add_xiaomee_day;
}__attribute__((packed));

//派派:设置_ex
#define PP_PET_SET_EX_CMD                	(0x181A |NEED_UPDATE)
struct  pp_pet_set_ex_in{
	uint32_t	catchtime;
	uint32_t	atk_frist;
	uint32_t	petid;
	char  		nick[16];
	uint32_t	exp;
	uint32_t	level;
	uint32_t	dv;
	uint32_t	nature;
	uint32_t	hp;
	uint32_t	max_hp;
	uint32_t	atk;
	uint32_t	sp_atk;
	uint32_t	def;
	uint32_t	sp_def;
	uint32_t	speed;
}__attribute__((packed));



/*
 * @brief 类的构造函数，创建保存小米修改记录的FD（UDP）和创建保存密码修改记录的FD（UDP）
 */
Csend_log::Csend_log()
{
	//小米修改记录
	const char * udp_ip = NULL;
    short  udp_port;
    udp_ip = config_get_strval("SU_LOG_IP");
    if(!udp_ip) {
        udp_ip = "10.1.1.89";
	}
	udp_port = config_get_intval("SU_LOG_PORT", 11001);
	this->log_fd = open_socket_udp(udp_ip,udp_port,&(this->log_addr));

}

int Csend_log::send (stru_log_item *p_logmesg )
{
	char buf[2000];
    PROTO_HEADER* ph = (PROTO_HEADER*)buf;
    ph->cmd_id = 0xA110;
    ph->id = p_logmesg->userid;
    ph->proto_length = sizeof (PROTO_HEADER) + sizeof(*p_logmesg) ;
    memcpy(buf + sizeof(PROTO_HEADER), p_logmesg, sizeof(*p_logmesg));
    sendto(this->log_fd, buf, ph->proto_length, 0,
			(const struct sockaddr *)&(this->log_addr), sizeof(this->log_addr));
    return SUCC;
}

int Csend_log::sendmsg ( char * recvbuf ,uint32_t adminid  )
{
	stru_log_item item={ };
	bool is_save=true;
	PROTO_HEADER * p_proto_header=(PROTO_HEADER *) recvbuf;	
	item.cmdid =p_proto_header->cmd_id;
	if((item.cmdid&0x0800)==0x0800 ){
		item.type=1;	
	}else{
		item.type=0;	
	}
	item.userid=p_proto_header->id;
	item.adminid=adminid;
	
	switch ( item.cmdid )
	{
		case USER_SET_ATTIRE_EX_CMD :{ 
				user_set_attire_ex_in *p_in=PRI_IN_POS;
				item.v1=p_in->attireid;		
				item.v2=p_in->count;		
			}
			break;
		case SU_CHANGE_CMD:{ 
				su_change_in*p_in=PRI_IN_POS;
				item.userid=p_in->userid;		
				item.v1=p_in->attrid;		
				item.v2=p_in->changvalue;		
			}
			break;
		case USER_ADD_ATTIRE_CMD:{ 
				user_add_attire_in *p_in=PRI_IN_POS;
				item.v1=p_in->attireid;		
				item.v2=p_in->count;		
				item.v3=p_in->attiretype;		
			}
			break;
	
		case USER_SALE_ATTIRE_CMD:{ 
				user_sale_attire_in *p_in=PRI_IN_POS;
				item.v1=p_in->attire_item.attireid;		
				item.v2=p_in->attire_item.count;		
				item.v3=p_in->attire_item.attiretype;		
			}
			break;
//---------PP---------------------------------------------
		case PP_CHANGE_XIAOMEE_CMD:{ 
				pp_change_xiaomee_in *p_in=PRI_IN_POS;
				item.v1=0;		
				item.v2=p_in->change_value;		
			}
			break;
	
		case PP_ATTIRE_SET_EX_CMD:{ 
				pp_attire_set_ex_in*p_in=PRI_IN_POS;
				item.v1=p_in->attireid;		
				item.v2=p_in->count;		
			}
			break;
	case PP_HOME_BUY_ATTIRE_CMD:{ 
				pp_home_buy_attire_in* p_in=PRI_IN_POS;
				item.v1=p_in->attireid;		
				item.v2=p_in->addcount;		
			}
			break;
	case PP_HOME_ATTIRE_SALE_CMD:{ 
				pp_attire_sale_in * p_in=PRI_IN_POS;
				item.v1=p_in->attireid;		
				item.v2=p_in->count;		
			}
			break;
	case PP_PET_SET_EX_CMD:{ 
				pp_pet_set_ex_in * p_in=PRI_IN_POS;
				item.v1=p_in->catchtime;		
				item.v2=p_in->level;		
				item.v3=p_in->speed;		
			}
			break;



	

		default :
		 	is_save=false;
			break;
	}

	if (is_save){
		if (item.adminid==0){
			return FAIL;	
		}

		this->send(&item );
	}

	return SUCC;

}

