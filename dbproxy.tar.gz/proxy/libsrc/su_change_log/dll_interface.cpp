/*
 * =====================================================================================
 *
 *	   Filename:  dll_interface.cpp
 *
 *	Description:  
 *
 *		Version:  1.0
 *		Created:  03/08/2010 02:52:29 PM
 *	   Revision:  none
 *	   Compiler:  gcc
 *
 *		 Author:  jim (xcwen), jim@taomee.com
 *		Company:  taomee
 *
 * =====================================================================================
 */
#include "proxy_dll_interface.h"
extern "C" {
#include <libtaomee/log.h>
}

#include "Csend_log.h"
Csend_log *send_log=NULL; 

void proxy_get_lib_info(stru_lib_info *p_out )
{
	stru_lib_info lib_info={
		"su_change_log",
		"20100602",
	};
 	*p_out=lib_info;
}


//程序开始启动时调用
int proxy_init_service ()
{
	send_log=new Csend_log();
	return 0;
}

//收到客户端报文时调用
//返回－1：表示该报文这需要proxy继续往下传。
//0:已经处理完毕，proxy不再处理
int proxy_process_client_cmd( char* recvbuf,int recvlen,stru_client_info * p_client_info , 
	           stru_proxy_interface_out *p_out	)
{
	send_log->sendmsg((char*)recvbuf,p_client_info->client_protoid );
	return -1;
}
//收到后端报文（一般是DBSER）时调用,
//返回－1：表示该报文这需要proxy继续往下传。
//0:已经处理完毕，proxy不再处理
int proxy_process_serv_return(char* recvbuf,int recvlen, stru_pri_buf * p_pri_buf,
	           stru_proxy_interface_out *p_out	)
{
	return -1;
}

//程序终止时调用
int proxy_fini_service (){
	return 0;
}


